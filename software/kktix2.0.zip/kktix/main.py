from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import pause, datetime
from getpass import getpass
import tkinter as tk
from selenium.webdriver.common.by import By
from tkinter import messagebox
from selenium.webdriver.chrome.options import Options

options = Options()
options.binary_location = "D:\\games\\gwapp\\googlechrom\\win7\\App\\Chrome-bin\\chrome.exe"
driver = webdriver.Chrome(chrome_options = options)

def acc_login():
    driver.get("https://kktix.com/users/sign_in?back_to=https%3A%2F%2Fkktix.com%2F")
    if driver.current_url != "https://kktix.com/" and driver.current_url != "https://kktix.com/#_=_" :
        driver.find_element_by_id("user_login").send_keys(email_entry.get())
        driver.find_element_by_id("user_password").send_keys(pass_entry.get())
        driver.find_elements_by_class_name("btn-login")[2].send_keys(Keys.RETURN)
    run()

def fb_login():
    driver.get("https://kktix.com/users/sign_in?back_to=https%3A%2F%2Fkktix.com%2F")
    if driver.current_url != "https://kktix.com/" and driver.current_url != "https://kktix.com/#_=_" :
        driver.find_element_by_class_name('btn-login').send_keys(Keys.RETURN)
        driver.find_element_by_id('email').send_keys(email_entry.get())
        driver.find_element_by_id('pass').send_keys(pass_entry.get())
        driver.find_element_by_id('loginbutton').send_keys(Keys.RETURN)
    run()

def get_ticket():
    cur_url = driver.current_url
    while True:
        if driver.current_url != cur_url:
            break        
        try:
            driver.find_elements_by_class_name('btn-primary')[-1].click()
        except :
            continue

        try:
            WebDriverWait(driver, 3).until(EC.alert_is_present(),
                                        'Timed out waiting for PA creation ' +
                                        'confirmation popup to appear.')
            alert = driver.switch_to.alert
            alert.accept()
            print("alert accepted")
        except TimeoutException:
            print("no alert")


def run():
    
    if driver.current_url != "https://kktix.com/" and driver.current_url != "https://kktix.com/#_=_" :
        warm_label.configure(text="登入失敗", fg="red")
        return 

    driver.get("https://kktix.com/events/"+event_entry.get()+"/registrations/new")

    today = datetime.datetime.today().date()
    dt = datetime.datetime(today.year, today.month, today.day, int(hour_entry.get()), int(min_entry.get()))
    now = datetime.datetime.now()
    
    if dt<now:
        warm_label.configure(text="時間錯誤", fg="red")
        return

    pause.until(dt)

    driver.refresh()

    time.sleep(5)
    if not driver.find_element_by_id("person_agree_terms").is_selected():
        WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.CSS_SELECTOR, "#person_agree_terms"))).click()

if __name__ == "__main__":

    
    window = tk.Tk()
    window.title('KKtix 搶票系統')
    window.configure(background='green')
    window.geometry('400x300')
    
    email_frame = tk.Frame(window)
    email_frame.pack(side=tk.TOP)
    email_label = tk.Label(email_frame, text='帳號:')
    email_label.pack(side=tk.LEFT)
    email_entry = tk.Entry(email_frame)
    email_entry.pack(side=tk.LEFT)

    pass_frame = tk.Frame(window)
    pass_frame.pack(side=tk.TOP)
    pass_label = tk.Label(pass_frame, text='密碼:')
    pass_label.pack(side=tk.LEFT)
    pass_entry = tk.Entry(pass_frame)
    pass_entry.pack(side=tk.LEFT)

    event_frame = tk.Frame(window)
    event_frame.pack(side=tk.TOP)
    event_label = tk.Label(event_frame, text='活動ID:')
    event_label.pack(side=tk.LEFT)
    event_entry = tk.Entry(event_frame, width="18")
    event_entry.pack(side=tk.LEFT)

    time_frame = tk.Frame(window)
    time_frame.pack(side=tk.TOP)
    time_label = tk.Label(time_frame, text='時間:')
    time_label.pack(side=tk.LEFT)
    hour_entry = tk.Entry(time_frame, width="7")
    hour_entry.pack(side=tk.LEFT)
    hour_label = tk.Label(time_frame, text='時')
    hour_label.pack(side=tk.LEFT)
    min_entry = tk.Entry(time_frame, width="7")
    min_entry.pack(side=tk.LEFT)
    min_label = tk.Label(time_frame, text='分')
    min_label.pack(side=tk.LEFT)
    
    top_frame = tk.Frame(window)
    top_frame.pack()
    bottom_frame = tk.Frame(window)
    bottom_frame.pack(side=tk.BOTTOM)

    warm_label = tk.Label(window)
    warm_label.pack()

    email_button = tk.Button(bottom_frame, text='email登入', fg='green', command=acc_login)
    email_button.pack(side=tk.LEFT)

    fb_button = tk.Button(bottom_frame, text='facebook登入', fg='blue', command=fb_login)
    fb_button.pack(side=tk.LEFT)

    rob_button = tk.Button(bottom_frame, text='開始搶票', fg='red', command=get_ticket)
    rob_button.pack(side=tk.LEFT)


    window.mainloop()